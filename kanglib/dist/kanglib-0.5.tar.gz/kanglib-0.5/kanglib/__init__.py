
from .calculations import calculate_weighted_value


def hello():
        print("Hello, World! Kang is coming")
        